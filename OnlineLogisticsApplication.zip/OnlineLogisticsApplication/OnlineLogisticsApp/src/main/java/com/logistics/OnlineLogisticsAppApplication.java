package com.logistics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineLogisticsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineLogisticsAppApplication.class, args);
	}

}
