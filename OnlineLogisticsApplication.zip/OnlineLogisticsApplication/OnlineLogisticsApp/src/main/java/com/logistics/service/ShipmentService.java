package com.logistics.service;

import com.logistics.exception.ResourceNotFoundException;
import com.logistics.model.Shipment;
import com.logistics.repository.ShipmentRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ShipmentService {
    
    private final ShipmentRepository repository;

    public ShipmentService(ShipmentRepository repository) {
        this.repository = repository;
    }

    public List<Shipment> getAllShipments() {
        return repository.findAll();
    }

    public Shipment getShipmentById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment not found with id: " + id));
    }

    public Shipment createShipment(Shipment shipment) {
        return repository.save(shipment);
    }

    public Shipment updateShipment(Long id, Shipment updatedShipment) {
        Shipment existingShipment = getShipmentById(id);
        existingShipment.setOrigin(updatedShipment.getOrigin());
        existingShipment.setDestination(updatedShipment.getDestination());
        existingShipment.setStatus(updatedShipment.getStatus());
        return repository.save(existingShipment);
    }

    public void deleteShipment(Long id) {
        Shipment shipment = getShipmentById(id);
        repository.delete(shipment);
    }
}
