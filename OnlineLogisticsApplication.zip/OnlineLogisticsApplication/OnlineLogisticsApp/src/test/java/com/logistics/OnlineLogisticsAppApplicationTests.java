package com.logistics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineLogisticsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
